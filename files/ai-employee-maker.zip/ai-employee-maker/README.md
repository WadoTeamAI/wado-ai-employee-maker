# AI社員を作るAI社員（ai-employee-maker）配布版

毎回チャットで説明し直している仕事を聞き取り、Claude の Skill（AI社員1人）に仕上げます。
ナレッジ・リファレンス・ワークフロー・正しいアウトプットの4つをそろえ、1回試して直すところまで一緒に進めます。

## 動作条件

- Claude Code（macOS / Windows / Linux）、または Skills が使える claude.ai（ブラウザ・アプリ）
- スクリプトは使いません（追加のインストールは不要です）
- 使えるプラン・画面の名前は変わることがあります。公式ヘルプで最新を確認してください

## インストール

Claude Code の場合:

```bash
unzip ai-employee-maker.zip -d ~/.claude/skills/
```

claude.ai の場合: 設定画面の Skills から、この zip をそのままアップロードします。

## 1分の動作確認

「AI社員を作りたい。任せたいのはセミナー後のお礼メール」のように話しかけます。AI社員の方から質問が返ってきます。

## 困ったとき

| 症状 | 対処 |
|---|---|
| スキルが呼ばれない | Claude Code なら `/ai-employee-maker` と打って直接呼び出す |
| 仕事を2つ頼んだら1つに絞られた | 仕様です。1人のAI社員に任せる仕事は1つ。2つ目は作り直して別のAI社員にします |
| 実績や数字を入れてほしい | 自分で渡した事実だけを使います。AIは数字を作りません |

## 同梱物

| ファイル | 中身 |
|---|---|
| `SKILL.md` | AI社員の手順と判断の基準 |
| `references/interview-sheet.md` | 聞き取りの質問10問 |
| `references/ai-employee-template.md` | 作るAI社員のファイル雛形 |
| `references/quality-checklist.md` | 試した結果の確認表 |
| `references/example-output.md` | 完成形の見本（お礼メール担当の例） |
| `README.md` | このファイル |

## 配布範囲

公式LINEに登録した方向けの特典です。再配布はご遠慮ください。※成果には個人差があります。
